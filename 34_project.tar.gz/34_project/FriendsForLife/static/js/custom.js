function like(postid) {
    var noLikes = parseInt(document.getElementById('nolikes'+postid).innerHTML);
    if(document.getElementById('likeField'+postid).value==1) {
        document.getElementById('nolikes'+postid).innerHTML = noLikes-1;
        document.getElementById('likeField'+postid).value = 0;
        document.getElementById('likeBtn'+postid).innerHTML = 'Like';
    } else {
        document.getElementById('nolikes'+postid).innerHTML = noLikes+1;
        document.getElementById('likeField'+postid).value = 1;
        document.getElementById('likeBtn'+postid).innerHTML = 'Unlike';
    }
}
