# a table to store posted messages
db.define_table('posts',
    Field('body','text',requires=IS_NOT_EMPTY(),label='What is on your mind?'),
    Field('pic','upload',label='Would you like to share some pics?'),
    Field('status','string',requires=IS_NOT_EMPTY(),default='Friends'), # Friends / Public / Deleted
    Field('postedat','datetime',readable=False,writable=False),
    Field('postedby','reference auth_user',readable=False,writable=False),
    Field('sharedflag','integer',readable=False,writable=False),
    Field('postedon','reference auth_user',readable=False,writable=False))

# a table to link two people
db.define_table('myfriends',
    Field('userid','reference auth_user'),
    Field('friendid','reference auth_user'),
    Field('status','string',default='Pending'))  # Pending / Accepted / Rejected / Blocked

# a table to store likes
db.define_table('likes',
    Field('postid','reference posts',readable=False,writable=False),
    Field('userid','reference auth_user',requires=IS_NOT_EMPTY()))

# a table to store chats
db.define_table('chats',
    Field('userid1','reference auth_user',requires=IS_NOT_EMPTY()),
    Field('userid2','reference auth_user',requires=IS_NOT_EMPTY()),
    Field('txt','string',requires=IS_NOT_EMPTY()),
    Field('readFlag','string',requires=IS_NOT_EMPTY(),default='N'))

db.define_table('logs',
    Field('log','text',requires=IS_NOT_EMPTY()))

# and define some global variables that will make code more compact
User, Friends, Posts, Logger, Likes, Chats = db.auth_user, db.myfriends, db.posts, db.logs, db.likes, db.chats
me, arg0, arg1 = auth.user_id, request.args(0), request.args(1)
myfriends = db(Friends.userid==me)(Friends.status=='Accepted')
myfriendRequests = db(Friends.userid==me)(Friends.status=='Pending')
alphabetical = User.first_name|User.last_name
def name_of(user): return '%(first_name)s %(last_name)s' % user
