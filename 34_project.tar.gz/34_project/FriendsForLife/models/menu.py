response.title = "Social Place for Friends"
response.meta.keywords = "social network"
response.menu = [
    (T('Home'), False, URL('default','home')),
    (T('Wall'), False, URL('default','wall')),
    (T('Friends'), False, URL('default','friends')),
    (T('Search'), False, URL('default','search')),
    ]
