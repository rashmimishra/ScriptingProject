def index():
    if auth.user: redirect(URL('home'))
    return locals()

def user():
    Logger.insert(log=str(request.args))
    if 'register' in request.args:
        fields_to_hide = ['picture','emailaccess','phoneno','phoneaccess','location','locationaccess','age','ageaccess','gender','genderaccess']
        for fieldname in fields_to_hide:
            field = db.auth_user[fieldname]
            field.readable = field.writable = False
    elif 'profile' in request.args:
        fields_to_hide = ['picture','emailaccess','phoneno','phoneaccess','location','locationaccess','age','ageaccess','gender','genderaccess']
        for fieldname in fields_to_hide:
            field = db.auth_user[fieldname]
            field.readable = field.writable = True
    return dict(form=auth())

def download():
    return response.download(request,db)

def call():
    session.forget()
    return service()

@auth.requires_login()
def getPosts():
    if arg1 is not None:
        q = Posts.postedon==arg1
    else:
        friends = [me]+[row.friendid for row in myfriends.select(Friends.friendid)]
        q1 = Posts.postedon.belongs(friends)
        q2 = Posts.status=='Public'
        q = q1 | q2
    posts = db(q)(Posts.status!='Deleted').select(orderby=~Posts.postedat,limitby=(0,100))

    likes = db(q)(Posts.status!='Deleted')(Posts.id==Likes.postid).select(Likes.postid,Likes.userid,orderby=~Likes.postid,limitby=(0,10000))
    postDict={}
    for like in likes:
        postid=str(like.postid)
        userid=str(like.userid)
        Logger.insert(log='like.postid = '+postid+', like.userid = '+userid)
        if(postid in postDict):
            postDict[postid].append(userid)
        else:
            postDict[postid]=list(userid)
#    for key in postDict.keys():
#        Logger.insert(log='From dict postid = '+key+', userids = '+"".join(postDict[key]))
    innerHtml = ""
    for post in posts:
        innerHtml = innerHtml+"<div id="+str(post.id)+" style='background: #f0f0f0; margin-bottom: 5px; padding: 8px;'>"

        if(post.postedby==me):
            postedBy = "You"
        else:
            postedBy = name_of(post.postedby)

        if(post.postedon==me):
            if(post.sharedflag==1):
                postedOn = "You"
            else:
                postedOn = "your"
        else:
            postedOn = name_of(post.postedon)+"'s"

        if(post.sharedflag==1):
            innerHtml = innerHtml+"<h3>"+str(A(postedOn,_href=URL('wall',args=post.postedon)))+" shared "+str(A(postedBy,_href=URL('wall',args=post.postedby)))+"'s post:</h3>"
        else:
            innerHtml = innerHtml+"<h3>"+str(A(postedBy,_href=URL('wall',args=post.postedby)))+" wrote on "+str(A(postedOn,_href=URL('wall',args=post.postedon)))+" wall:</h3>"

        innerHtml = innerHtml+"<div style='clear:both'>"+str(MARKMIN(post.body))+"</div>"
        innerHtml = innerHtml+"<label></label>"
        if post.pic:
            innerHtml = innerHtml+"<p><img src ='/FriendsForLife/default/download/"+post.pic+"'/></p>"

        if str(post.id) in postDict:
            noLikes=len(postDict[str(post.id)])
            innerHtml = innerHtml+"<label id='nolikes"+str(post.id)+"'>"+str(noLikes)+"</label> likes"
            if postDict[str(post.id)].count(str(me))>0:
                innerHtml = innerHtml+"<input type='hidden' id='likeField"+str(post.id)+"' value=1>"
                innerHtml = innerHtml+"<button id='likeBtn"+str(post.id)+"' onclick=\"ajax('"+URL('like',args=(post.id))+"',[],null); like("+str(post.id)+");\">Unlike</button>"
            else:
                innerHtml = innerHtml+"<input type='hidden' id='likeField"+str(post.id)+"' value=0>"
                innerHtml = innerHtml+"<button id='likeBtn"+str(post.id)+"' onclick=\"ajax('"+URL('like',args=(post.id))+"',[],null); like("+str(post.id)+");\">Like</button>"
        else:
            innerHtml = innerHtml+"<label id='nolikes"+str(post.id)+"'>0</label> likes"
            innerHtml = innerHtml+"<input type='hidden' id='likeField"+str(post.id)+"' value=0>"
            innerHtml = innerHtml+"<button id='likeBtn"+str(post.id)+"' onclick=\"ajax('"+URL('like',args=(post.id))+"',[],null); like("+str(post.id)+");\">Like</button>"

        if(postedBy!="You" and not (postedOn=="You" and post.sharedflag==1)):
            innerHtml = innerHtml+"<button onclick=\"ajax('"+URL('share',args=(post.id))+"',[],'posts');\">Share</button>"

        innerHtml = innerHtml+"</div>"
    return innerHtml

# our home page, will show our posts and posts by friends
@auth.requires_login()
def home():
    Posts.postedby.default = me
    Posts.postedon.default = me
    Posts.postedat.default = request.now
    Posts.sharedflag.default = 0
    Posts.status.default ='Friends'
    crud.settings.formstyle = 'table2cols'
    form = crud.create(Posts)
    return locals()

# our wall, will show our profile and our own posts
@auth.requires_login()
def wall():
    friendFlag = 1
    if arg0 is not None:
        user = db(User.id==arg0).select()[0]
        if not user or not (user.id==me or myfriends(Friends.friendid==user.id).count()):
            friendFlag = 0
    else:
        user = db(User.id==me).select()[0]

    fields_to_hide = ['emailaccess','phoneaccess','locationaccess','ageaccess','genderaccess']
    for fieldname in fields_to_hide:
        field = db.auth_user[fieldname]
        field.readable = field.writable = False

    if (user.emailaccess!='All' and friendFlag == 0):
        db.auth_user['email'].readable = False
        db.auth_user['email'].writable = False
    if (user.phoneaccess!='All' and friendFlag == 0):
        db.auth_user['phoneno'].readable = False
        db.auth_user['phoneno'].writable = False
    if (user.locationaccess!='All' and friendFlag == 0):
        db.auth_user['location'].readable = False
        db.auth_user['location'].writable = False
    if (user.ageaccess!='All' and friendFlag == 0):
        db.auth_user['age'].readable = False
        db.auth_user['age'].writable = False
    if (user.genderaccess!='All' and friendFlag == 0):
        db.auth_user['gender'].readable = False
        db.auth_user['gender'].writable = False
    if (not user.picture):
        db.auth_user['picture'].readable = False
        db.auth_user['picture'].writable = False

    return locals()

# a page for searching friends and requesting 


@auth.requires_login()
def search():
    form = SQLFORM.factory(Field('name',requires=IS_NOT_EMPTY()))
    if form.accepts(request):
        tokens = form.vars.name.split()
        query = reduce(lambda a,b:a&b,
                       [User.first_name.contains(k)|User.last_name.contains(k) \
                            for k in tokens])
        people = db(query)(User.id!=me).select(orderby=alphabetical)
        friends = {friend['myfriends'].friendid:friend['myfriends'].status for friend in db(Friends.userid==me).select(orderby=alphabetical)}
        friends.update({friend['myfriends'].userid:friend['myfriends'].status for friend in db(Friends.friendid==me).select(orderby=alphabetical)})
    else:
        people = []
        friends = []
    return locals()

# a page for accepting and denying friendship requests
@auth.requires_login()
def friends():
    friends = db(User.id==Friends.friendid)(Friends.userid==me)(Friends.status=='Accepted').select(orderby=alphabetical)
    requests = db(User.id==Friends.userid)(Friends.friendid==me)(Friends.status=='Pending').select(orderby=alphabetical)
    return locals()

def getFriends():
    friends = db(User.id==Friends.friendid)(Friends.userid==me)(Friends.status=='Accepted').select(orderby=alphabetical)
    innerHtml = ""
    for friend in friends:
        innerHtml = innerHtml + "<tr>"
        innerHtml = innerHtml + "<td>"+str(A(name_of(friend.auth_user),_href=URL('wall',args=friend.auth_user.id)))+"</td>"
        innerHtml = innerHtml + "<td><button onclick=\"ajax('"+URL('friendship',args=('remove',friend.auth_user.id))+"',[],null); $(this).parent().html('Denied')\">deny</button></td>"
        innerHtml = innerHtml+"<td><button onclick=\"window.open('"+URL('chat',args=(friend.auth_user.id))+"', '"+name_of(friend.auth_user)+"', 'width=300,height=400,scrollbars=yes');\">chat</button></td>"
        innerHtml = innerHtml + "</tr>"
        Logger.insert(log='innerHtml '+innerHtml)
    return innerHtml

# this is the Ajax callback
@auth.requires_login()
def friendship():
    """AJAX callback!"""
#    Logger.insert(log='AJAX callback! with args '+arg0+' and '+arg1)
#    if request.env.request_method!='POST': raise HTTP(400)
#    Logger.insert(log='Modified Inside friendship with args '+arg0+' and '+arg1)
    if arg0=='request' and not Friends(userid=arg1,friendid=me):
        # insert a new friendship request
#        Logger.insert(log='Inside request with userid = '+str(me)+' and friendid = '+arg1)
        Friends.insert(userid=me,friendid=arg1,status='Pending')
    elif arg0=='accept':
        # accept an existing friendship request
        Logger.insert(log='Inside accept with friendid = '+str(me)+' and userid = '+arg1)
        db(Friends.friendid==me)(Friends.userid==arg1).update(status='Accepted')
        if not db(Friends.userid==me)(Friends.friendid==arg1).count():
            Logger.insert(log='Inserting record for userid = '+str(me)+' and friendid = '+arg1)
            Friends.insert(userid=me,friendid=arg1,status='Accepted')
        return getFriends()
    elif arg0=='deny':
        # deny an existing friendship request
        Logger.insert(log='Inside deny with friendid = '+str(me)+' and userid = '+arg1)
        db(Friends.friendid==me)(Friends.userid==arg1).update(status='Rejected')
    elif arg0=='remove':
        # delete a previous friendship request
#        Logger.insert(log='Inside remove with friendid = '+str(me)+' and userid = '+arg1)
        db(Friends.userid==me)(Friends.friendid==arg1).update(status='Blocked')
        db(Friends.friendid==me)(Friends.userid==arg1).update(status='Blocked')

# this is the Ajax callback
@auth.requires_login()
def like():
    """AJAX callback!"""
    Logger.insert(log='AJAX callback! with args '+arg0)
#    if request.env.request_method!='POST': raise HTTP(400)
    Logger.insert(log='Modified Inside like with args '+arg0)

    if not db(Likes.postid==arg0)(Likes.userid==me).count():
        Logger.insert(log='Liking the post ')
        Likes.insert(userid=me,postid=arg0)
    else:
        Logger.insert(log='Unliking the post ')
        db(Likes.postid==arg0)(Likes.userid==me).delete()

# this is the Ajax callback
@auth.requires_login()
def share():
    """AJAX callback!"""
    Logger.insert(log='AJAX callback! with args '+arg0)
    if request.env.request_method!='POST': raise HTTP(400)
    Logger.insert(log='Modified Inside share with args '+arg0)
    post = db(Posts.id==arg0).select()[0]
    Logger.insert(log='Got post.postedby='+str(post.postedby)+', post.body='+str(post.body))
    Posts.insert(body=post.body,postedat=request.now,postedby=post.postedby,sharedflag=1,postedon=me)
    Logger.insert(log='After inserting post ')
    innerHtml = getPosts()
    return innerHtml

def mylog():
    #logs = db(Logger.id==Logger.id).select()
    crud.settings.formstyle = 'table2cols'
    form = crud.create(Posts)
    form1 = crud.create(Logger)

@auth.requires_login()
def chat():
    Logger.insert(log='Chat with args '+arg0)
#    if request.env.request_method!='POST': raise HTTP(400)
    if arg0 is not None:
        friend = db(User.id==arg0).select()[0]
        user = me
    else:
        friend = []
        user = []
    return locals()

@auth.requires_login()
def postChat():
    Logger.insert(log='post chat with args '+arg0+' '+arg1)
#    if request.env.request_method!='POST': raise HTTP(400)
    if arg0 is not None:
        Chats.insert(userid1=me,userid2=arg0,txt=arg1)
        return getChats()

@auth.requires_login()
def getChats():
    Logger.insert(log='get chats with args '+arg0)
#    if request.env.request_method!='POST': raise HTTP(400)
    if arg0 is not None:
        q1 = Chats.userid1==me
        q2 = Chats.userid2==arg0
        q3 = Chats.userid1==arg0
        q4 = Chats.userid2==me
        q = (q1 & q2) | (q3 & q4)
        Logger.insert(log='val '+str(db(q).select(Chats.id.max()).first()))
        maxID=db(q).select(Chats.id.max()).first()['MAX(chats.id)']
        Logger.insert(log='maxID '+str(maxID))
        chats = db(q)(Chats.id>maxID-100)(User.id==Chats.userid1).select(Chats.txt,User.first_name,User.last_name,orderby=Chats.id)
        Logger.insert(log='maxID '+str(chats))
        db(q3 & q4).update(readFlag='Y')
        innerHtml = ""
        for chat in chats:
            innerHtml = innerHtml + "<p>"
            innerHtml = innerHtml + str(chat.auth_user.first_name) + " " + str(chat.auth_user.last_name) + " : "
            innerHtml = innerHtml + str(chat.chats.txt) + "</p>"
        return innerHtml

def checkChats():
    if me:
        Logger.insert(log='check chats for '+str(me))
        newChatCount = db(Chats.userid2==me)(Chats.readFlag=='N').count()
        Logger.insert(log='newChatCount '+str(newChatCount))
        if(newChatCount>0):
            users = db(Chats.userid2==me)(Chats.readFlag=='N').select(Chats.userid1,distinct=True)
            Logger.insert(log='users '+str(users))
            userids=[]
            for u in users:
                Logger.insert(log='user '+str(u.userid1))
                userids.append(str(u.userid1))
            return "<input type='hidden' id='chatUsers' value='"+",".join(userids)+"'/>"
        else:
            return "<input type='hidden' id='chatUsers' value=''/>"
    else:
        return "<input type='hidden' id='chatUsers' value=''/>"
