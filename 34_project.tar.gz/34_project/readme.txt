Url for the code-

https://rashmiiiith.pythonanywhere.com/FriendsForLife


Anyone register using register page

Search for friends request for friendship

Can chat with friends 

Post on wall like and share the posts 

Users can set few fields to be seen only by friends or everyone.

