Url for the code-

https://rashmiiiith.pythonanywhere.com/FriendsForLife

Please disable popblocker for chat to work, 
Please allow unsafe scripts to run in order to user share feature.


Anyone register using register page

Search for friends request for friendship

Can chat with friends 

Post on wall like and share the posts 

Users can set few fields to be seen only by friends or everyone.

